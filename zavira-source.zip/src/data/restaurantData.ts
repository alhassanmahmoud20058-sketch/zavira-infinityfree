export type MenuCategory =
  | 'Starters'
  | 'Main Courses'
  | 'Local Specialties'
  | 'Grills and Barbecue'
  | 'Desserts'
  | 'Drinks';

export interface MenuItem {
  id: string;
  name: string;
  category: MenuCategory;
  description: string;
  priceNaira: number;
  originNote: string;
  prepTime: string;
  image: string;
  featured?: boolean;
}

export interface SpecialOffer {
  id: string;
  label: string;
  title: string;
  subtitle: string;
  description: string;
  priceNaira: number;
  originalPriceNaira: number;
  serves: string;
  image: string;
}

export interface GalleryPhoto {
  id: string;
  title: string;
  category: string;
  caption: string;
  image: string;
  spanClass: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  rating: number;
  quote: string;
  dishMentioned: string;
}

export const MENU_CATEGORIES: MenuCategory[] = [
  'Starters',
  'Main Courses',
  'Local Specialties',
  'Grills and Barbecue',
  'Desserts',
  'Drinks',
];

export const IMAGES = {
  hero: '/src/assets/images/hero_fine_dining_spread_1795551619223.jpg',
  interior: '/src/assets/images/about_restaurant_interior_1795551619325.jpg',
  jollofDuck: '/src/assets/images/dish_jollof_smoked_duck_1795551620670.jpg',
  suyaRibeye: '/src/assets/images/dish_suya_ribeye_grill_1795551620513.jpg',
  pepperSoup: '/src/assets/images/dish_pepper_soup_seafood_1795551620930.jpg',
  plantainTartare: '/src/assets/images/dish_plantain_tartare_starter_1795551621443.jpg',
  cacaoDessert: '/src/assets/images/dish_chocolate_plantain_dessert_1795551622450.jpg',
  zoboCocktail: '/src/assets/images/dish_hibiscus_cocktail_drink_1795551623155.jpg',
  openFireChef: '/src/assets/images/gallery_open_fire_chef_1795551624339.jpg',
  feastPlatter: '/src/assets/images/offer_feast_platter_1795551624641.jpg',
};

export const MENU_ITEMS: MenuItem[] = [
  // Starters
  {
    id: 'starter-tartare',
    name: 'Atlantic Sea Bass & Kelewele Tartare',
    category: 'Starters',
    description:
      'Line-caught sea bass cured in calamansi, layered over spiced plantain crisps, whipped avocado crema, and zobo reduction.',
    priceNaira: 18500,
    originNote: 'Lagos Coast · Cold Starter',
    prepTime: '15 min',
    image: IMAGES.plantainTartare,
    featured: true,
  },
  {
    id: 'starter-peppersoup',
    name: 'Royal Tiger Prawn Pepper Soup',
    category: 'Starters',
    description:
      'Velvety spiced broth infused with uda, ehuru, and scent leaf oil, served with charred jumbo prawns and red snapper.',
    priceNaira: 21000,
    originNote: 'Delta Spice · Signature Broth',
    prepTime: '18 min',
    image: IMAGES.pepperSoup,
  },
  {
    id: 'starter-marrow-suya',
    name: 'Roasted Bone Marrow & Yaji Crostini',
    category: 'Starters',
    description:
      'Hearth-split beef marrow glazed with smoked suya butter, pickled shallots, and artisan sourdough.',
    priceNaira: 16500,
    originNote: 'Open Hearth · Shareable',
    prepTime: '14 min',
    image: IMAGES.suyaRibeye,
  },

  // Main Courses
  {
    id: 'main-jollof-duck',
    name: 'Firewood Jollof & Seared Duck Breast',
    category: 'Main Courses',
    description:
      'Slow-smoked basmati party jollof finished over cherrywood embers, crowned with crispy duck breast and caramelized dodo.',
    priceNaira: 34500,
    originNote: 'House Signature · Wood-Fired',
    prepTime: '25 min',
    image: IMAGES.jollofDuck,
    featured: true,
  },
  {
    id: 'main-lobster-lamb',
    name: 'Butter-Poached Lobster & Lamb Medallions',
    category: 'Main Courses',
    description:
      'Char-grilled Atlantic lobster tail paired with suya-crusted lamb loin, charred asparagus, and roasted pepper jus.',
    priceNaira: 52000,
    originNote: 'Chef Tasting · Surf & Turf',
    prepTime: '28 min',
    image: IMAGES.hero,
  },
  {
    id: 'main-snapper-claypot',
    name: 'Wild Red Snapper in Scent Leaf Emulsion',
    category: 'Main Courses',
    description:
      'Pan-seared whole snapper fillet resting in aromatic coastal broth with yam fondant and blistered tomatoes.',
    priceNaira: 31000,
    originNote: 'Atlantic Catch · Gluten-Free',
    prepTime: '22 min',
    image: IMAGES.pepperSoup,
  },

  // Local Specialties
  {
    id: 'local-ofada-heritage',
    name: 'Heritage Ofada & Braised Short Rib',
    category: 'Local Specialties',
    description:
      'Unpolished Ogun heirloom rice paired with slow-braised short rib in fermented locust bean and smoked green pepper ayamase.',
    priceNaira: 29500,
    originNote: 'Ogun Heirloom · Slow Braised',
    prepTime: '22 min',
    image: IMAGES.jollofDuck,
  },
  {
    id: 'local-asun-feast',
    name: 'Smoked Pepper Goat Asun & Yam Mille-Feuille',
    category: 'Local Specialties',
    description:
      'Charred goat shoulder tossed in habanero and sweet onion oil alongside crisp layered white yam.',
    priceNaira: 27000,
    originNote: 'Traditional Hearth · Fiery',
    prepTime: '20 min',
    image: IMAGES.feastPlatter,
  },
  {
    id: 'local-fisherman-pot',
    name: 'Rivers Fisherman Claypot',
    category: 'Local Specialties',
    description:
      'Simmered native pot of tiger prawns, periwinkle, fresh croaker, and hand-pounded yam dumplings.',
    priceNaira: 36000,
    originNote: 'Port Harcourt Inspired · Claypot',
    prepTime: '26 min',
    image: IMAGES.pepperSoup,
  },

  // Grills and Barbecue
  {
    id: 'grill-tomahawk-suya',
    name: 'Yaji-Crusted Prime Tomahawk Ribeye',
    category: 'Grills and Barbecue',
    description:
      '45-day aged beef tomahawk crusted in house-milled peanut suya spice, served with roasted bone marrow and vine tomatoes.',
    priceNaira: 68000,
    originNote: '900g Dry-Aged · For Two',
    prepTime: '32 min',
    image: IMAGES.suyaRibeye,
    featured: true,
  },
  {
    id: 'grill-prawn-skewers',
    name: 'Charcoal-Grilled Jumbo Prawns & Lime',
    category: 'Grills and Barbecue',
    description:
      'Lagos lagoon tiger prawns basted in garlic palm-oil butter, blistered over white oak charcoal with fresh lime.',
    priceNaira: 33500,
    originNote: 'Charcoal Grill · Coastal',
    prepTime: '18 min',
    image: IMAGES.feastPlatter,
  },
  {
    id: 'grill-lamb-rack',
    name: 'Open-Flame Spiced Rack of Lamb',
    category: 'Grills and Barbecue',
    description:
      'Marinated in ginger, alligator pepper, and rosemary, seared over open flames and sliced tableside.',
    priceNaira: 44000,
    originNote: 'Open Flame · Medium Rare',
    prepTime: '24 min',
    image: IMAGES.hero,
  },

  // Desserts
  {
    id: 'dessert-cacao-fondant',
    name: 'Ondo Single-Origin Cacao Lava Tart',
    category: 'Desserts',
    description:
      'Warm 72% Nigerian dark chocolate tart with roasted caramelized plantain gelato, cacao soil, and edible gold leaf.',
    priceNaira: 14500,
    originNote: 'Ondo Cacao · Baked to Order',
    prepTime: '15 min',
    image: IMAGES.cacaoDessert,
    featured: true,
  },
  {
    id: 'dessert-tiger-nut',
    name: 'Roasted Tigernut & Vanilla Mille-Feuille',
    category: 'Desserts',
    description:
      'Crisp caramelized puff pastry layered with chilled kunu aya cream and toasted cashew praline.',
    priceNaira: 13000,
    originNote: 'Artisan Pastry · Chilled',
    prepTime: '10 min',
    image: IMAGES.cacaoDessert,
  },
  {
    id: 'dessert-coconut-puff',
    name: 'Warm Cardamom Puff-Puff & Salted Caramel',
    category: 'Desserts',
    description:
      'Golden brioche-light doughnuts dusted in cinnamon sugar with warm palm-sugar caramel and coconut chantilly.',
    priceNaira: 11500,
    originNote: 'House Classic · Warm',
    prepTime: '12 min',
    image: IMAGES.cacaoDessert,
  },

  // Drinks
  {
    id: 'drink-smoked-zobo',
    name: 'Smoked Hibiscus Zobo Old Fashioned',
    category: 'Drinks',
    description:
      'Small-batch bourbon infused with spiced zobo reduction, clove bitters, blood orange, and star anise smoke.',
    priceNaira: 12500,
    originNote: 'Signature Cocktail · Aged Spirit',
    prepTime: '6 min',
    image: IMAGES.zoboCocktail,
    featured: true,
  },
  {
    id: 'drink-palm-negroni',
    name: 'Victoria Island Palm & Citrus Negroni',
    category: 'Drinks',
    description:
      'Botanical gin stirred with artisanal bitter aperitivo, roasted pineapple shrub, and dehydrated lime.',
    priceNaira: 11500,
    originNote: 'House Aperitif · Chilled',
    prepTime: '5 min',
    image: IMAGES.zoboCocktail,
  },
  {
    id: 'drink-ginger-zobo-zero',
    name: 'Spiced Ginger & Hibiscus Elixir (Zero-Proof)',
    category: 'Drinks',
    description:
      'Cold-pressed Kaduna ginger, organic hibiscus petals, crushed mint, and sparkling spring water over hand-cut ice.',
    priceNaira: 7500,
    originNote: 'Zero-Proof · Botanical',
    prepTime: '4 min',
    image: IMAGES.zoboCocktail,
  },
];

export const SPECIAL_OFFERS: SpecialOffer[] = [
  {
    id: 'offer-chef-special',
    label: "Chef's Special",
    title: 'Five-Course Open Hearth Tasting',
    subtitle: 'Curated nightly by Executive Chef Tunde Adeyemi',
    description:
      'Includes Sea Bass Tartare, Tiger Prawn Pepper Soup, Firewood Jollof with Seared Duck, Lamb Medallions, and Ondo Cacao Fondant.',
    priceNaira: 78000,
    originalPriceNaira: 95000,
    serves: 'Per Guest · Optional Pairing Available',
    image: IMAGES.hero,
  },
  {
    id: 'offer-today-special',
    label: "Today's Special",
    title: 'Smoked Tomahawk & Bone Marrow Duo',
    subtitle: 'Available Thursday to Sunday evenings',
    description:
      'Our 900g yaji-crusted dry-aged ribeye paired with two Smoked Hibiscus Zobo Old Fashioned cocktails and charred vine tomatoes.',
    priceNaira: 82000,
    originalPriceNaira: 93000,
    serves: 'Serves 2 Guests · Limited Nightly Cuts',
    image: IMAGES.suyaRibeye,
  },
  {
    id: 'offer-family-package',
    label: 'Family Packages · Combo Meals',
    title: 'The Zavira Celebration Table Feast',
    subtitle: 'Designed for Sunday gatherings & private celebrations',
    description:
      'Whole claypot firewood Jollof, grilled lagoon prawns, peppered suya beef skewers, golden dodo, and four botanical citrus elixirs.',
    priceNaira: 135000,
    originalPriceNaira: 162000,
    serves: 'Serves 4–5 Guests · Dine-in or Express Delivery',
    image: IMAGES.feastPlatter,
  },
];

export const GALLERY_PHOTOS: GalleryPhoto[] = [
  {
    id: 'gal-1',
    title: 'The Main Dining Room',
    category: 'Restaurant Interior',
    caption: 'Warm antique brass lighting and charcoal timber framing the glowing hearth.',
    image: IMAGES.interior,
    spanClass: 'md:col-span-2 md:row-span-2',
  },
  {
    id: 'gal-2',
    title: 'Live-Fire Kitchen Craft',
    category: 'Food Preparation',
    caption: 'Precision plating steps away from white oak and cherrywood embers.',
    image: IMAGES.openFireChef,
    spanClass: 'md:col-span-2 md:row-span-1',
  },
  {
    id: 'gal-3',
    title: 'Celebration Spreads',
    category: 'Special Occasions',
    caption: 'Shared platters crafted for milestone dinners and executive evenings.',
    image: IMAGES.feastPlatter,
    spanClass: 'md:col-span-1 md:row-span-1',
  },
  {
    id: 'gal-4',
    title: 'Atlantic Surf & Turf',
    category: 'Signature Dishes',
    caption: 'Butter-poached lobster and suya-crusted lamb medallions on stoneware.',
    image: IMAGES.hero,
    spanClass: 'md:col-span-1 md:row-span-1',
  },
  {
    id: 'gal-5',
    title: 'Smoked Zobo Lounge',
    category: 'Bar & Mixology',
    caption: 'Hand-carved crystal ice and West African botanical infusions.',
    image: IMAGES.zoboCocktail,
    spanClass: 'md:col-span-2 md:row-span-1',
  },
  {
    id: 'gal-6',
    title: 'Single-Origin Cacao Finale',
    category: 'Patisserie',
    caption: 'Warm Ondo cacao lava tart paired with caramelized plantain gelato.',
    image: IMAGES.cacaoDessert,
    spanClass: 'md:col-span-2 md:row-span-1',
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'rev-1',
    name: 'Amaka Okafor',
    role: 'Creative Director, Lagos · Anniversary Dinner (Demo Review)',
    rating: 5,
    quote:
      'The transition from the wood-fired hearth aroma to the first spoonful of prawn pepper soup was unforgettable. Every detail of the room and pacing felt truly world-class.',
    dishMentioned: 'Firewood Jollof & Seared Duck Breast',
  },
  {
    id: 'rev-2',
    name: 'Chidi Nwosu',
    role: 'Managing Partner · Executive Hosting (Demo Review)',
    rating: 5,
    quote:
      'We hosted twelve international partners at Zavira and they are still talking about the yaji-crusted tomahawk and smoked zobo old fashioned. Service was effortless.',
    dishMentioned: 'Yaji-Crusted Prime Tomahawk Ribeye',
  },
  {
    id: 'rev-3',
    name: 'Folake Adeyinka',
    role: 'Food Writer · Weekend Tasting (Demo Review)',
    rating: 5,
    quote:
      'Rarely do you find a kitchen that respects Nigerian culinary heritage while pushing technique this far. The kelewele sea bass tartare and cacao lava tart belong on a global stage.',
    dishMentioned: 'Atlantic Sea Bass & Kelewele Tartare',
  },
  {
    id: 'rev-4',
    name: 'Damilola Balogun',
    role: 'Architect · Sunday Family Feast (Demo Review)',
    rating: 5,
    quote:
      'From booking our table online to ordering a Celebration Table Feast for Sunday at home, the entire experience is seamless, warm, and deeply memorable.',
    dishMentioned: 'The Zavira Celebration Table Feast',
  },
];

export function formatNaira(amount: number): string {
  return `₦${amount.toLocaleString('en-NG')}`;
}
