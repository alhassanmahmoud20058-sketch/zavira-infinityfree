import { useState } from 'react';
import { MapPin, Navigation, ExternalLink } from 'lucide-react';

interface Landmark {
  id: string;
  name: string;
  distance: string;
  x: number;
  y: number;
  isPrimary?: boolean;
}

const LANDMARKS: Landmark[] = [
  {
    id: 'zavira',
    name: 'ZAVIRA Flagship Dining Room',
    distance: '14B Adeola Odeku St, Victoria Island',
    x: 52,
    y: 48,
    isPrimary: true,
  },
  {
    id: 'eko',
    name: 'Adetokunbo Ademola Roundabout',
    distance: '3 min drive · Valet Access',
    x: 74,
    y: 34,
  },
  {
    id: 'atlantic',
    name: 'Ahmadu Bello Waterfront',
    distance: '4 min drive · Coastal Boulevard',
    x: 28,
    y: 66,
  },
];

export function LocationMapCard() {
  const [selected, setSelected] = useState<Landmark>(LANDMARKS[0]);

  return (
    <div className="rounded-2xl overflow-hidden bg-[#151311] border border-[#C9A45C]/25 flex flex-col h-full min-h-[380px]">
      <div className="relative flex-1 min-h-[280px] bg-[#100F0D] overflow-hidden">
        {/* Stylized Architectural Street Grid (Demonstration Map) */}
        <svg
          viewBox="0 0 400 280"
          className="w-full h-full object-cover opacity-80"
          aria-hidden="true"
        >
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path
                d="M 40 0 L 0 0 0 40"
                fill="none"
                stroke="rgba(201,164,92,0.08)"
                strokeWidth="1"
              />
            </pattern>
          </defs>
          <rect width="400" height="280" fill="url(#grid)" />

          {/* Lagoon / Atlantic shoreline silhouette */}
          <path
            d="M 0 230 Q 120 205 240 235 T 400 210 L 400 280 L 0 280 Z"
            fill="rgba(201,164,92,0.07)"
          />
          <path
            d="M 0 230 Q 120 205 240 235 T 400 210"
            fill="none"
            stroke="rgba(201,164,92,0.28)"
            strokeWidth="1.5"
          />

          {/* Victoria Island Avenues */}
          <path d="M 20 140 L 380 120" stroke="rgba(244,239,230,0.22)" strokeWidth="3" />
          <path d="M 90 20 L 140 250" stroke="rgba(244,239,230,0.14)" strokeWidth="2" />
          <path d="M 220 15 L 200 255" stroke="rgba(244,239,230,0.18)" strokeWidth="2.5" />
          <path d="M 310 25 L 290 245" stroke="rgba(244,239,230,0.12)" strokeWidth="1.5" />
          <path d="M 30 78 L 365 65" stroke="rgba(244,239,230,0.12)" strokeWidth="1.5" />

          {/* Roundabout */}
          <circle
            cx="296"
            cy="95"
            r="14"
            fill="#151311"
            stroke="rgba(201,164,92,0.45)"
            strokeWidth="2"
          />

          {/* Road Labels */}
          <text x="58" y="128" fill="rgba(244,239,230,0.45)" fontSize="9" letterSpacing="2">
            ADEOLA ODEKU STREET
          </text>
          <text x="18" y="258" fill="rgba(201,164,92,0.55)" fontSize="9" letterSpacing="2">
            ATLANTIC WATERFRONT
          </text>
        </svg>

        {/* Interactive Landmark Markers */}
        {LANDMARKS.map((landmark) => {
          const isActive = selected.id === landmark.id;
          return (
            <button
              key={landmark.id}
              type="button"
              onClick={() => setSelected(landmark)}
              style={{ left: `${landmark.x}%`, top: `${landmark.y}%` }}
              aria-label={`Select ${landmark.name}`}
              className={`absolute -translate-x-1/2 -translate-y-1/2 transition-transform duration-200 ${
                isActive ? 'scale-110 z-20' : 'hover:scale-105 z-10'
              }`}
            >
              <span
                className={`flex items-center justify-center rounded-full shadow-lg border ${
                  landmark.isPrimary
                    ? 'w-11 h-11 bg-[#C9A45C] text-[#0C0B0A] border-[#F4EFE6]'
                    : 'w-8 h-8 bg-[#1C1917] text-[#C9A45C] border-[#C9A45C]/50'
                }`}
              >
                <MapPin className={landmark.isPrimary ? 'w-5 h-5' : 'w-4 h-4'} />
              </span>
            </button>
          );
        })}

        <div className="absolute top-3 left-3 px-3 py-1.5 rounded-md bg-black/75 backdrop-blur-sm border border-white/10 text-[11px] text-[#B8AFA3]">
          Interactive Location Preview · Demonstration Map
        </div>
      </div>

      {/* Selected Location Detail Bar */}
      <div className="p-5 bg-[#191614] border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-0.5">
          <p className="text-xs text-[#C9A45C] font-medium flex items-center gap-1.5">
            <Navigation className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{selected.name}</span>
          </p>
          <p className="text-sm text-[#B8AFA3]">{selected.distance}</p>
        </div>
        <a
          href="https://maps.google.com/?q=Adeola+Odeku+Street+Victoria+Island+Lagos"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-[#C9A45C]/40 text-xs font-medium text-[#F4EFE6] hover:bg-[#C9A45C] hover:text-[#0C0B0A] transition-colors whitespace-nowrap shrink-0"
        >
          <span>Open in Maps</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
}
