import { useState } from 'react';
import { X, Plus, Minus, Trash2, ShoppingBag, CheckCircle2, ArrowRight } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { formatNaira } from '../data/restaurantData';
import { ResilientImage } from './ResilientImage';

export interface CartItem {
  id: string;
  name: string;
  priceNaira: number;
  image: string;
  quantity: number;
  categoryLabel: string;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export function CartDrawer({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartDrawerProps) {
  const [step, setStep] = useState<'bag' | 'checkout' | 'confirmed'>('bag');
  const [fulfillment, setFulfillment] = useState<'delivery' | 'pickup'>('delivery');
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState('');
  const [orderRef, setOrderRef] = useState('');

  const subtotal = items.reduce((sum, item) => sum + item.priceNaira * item.quantity, 0);
  const vat = Math.round(subtotal * 0.075);
  const deliveryFee = items.length > 0 && fulfillment === 'delivery' ? 3500 : 0;
  const total = subtotal + vat + deliveryFee;

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !phone.trim()) {
      setFormError('Please provide your full name and phone number.');
      return;
    }
    if (fulfillment === 'delivery' && !address.trim()) {
      setFormError('Please enter a delivery address in Lagos.');
      return;
    }
    setFormError('');
    const refCode = `ZAV-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderRef(refCode);
    setStep('confirmed');
    onClearCart();
  };

  const handleClose = () => {
    onClose();
    setTimeout(() => {
      if (step === 'confirmed') {
        setStep('bag');
        setCustomerName('');
        setPhone('');
        setAddress('');
        setNotes('');
      }
    }, 300);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal="true" aria-label="Online Order Bag">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={handleClose}
            className="fixed inset-0 bg-black/75 backdrop-blur-sm"
          />

          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-10 w-full max-w-md bg-[#13110F] border-l border-[#C9A45C]/20 text-[#F4EFE6] flex flex-col h-full shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-white/10">
              <div className="flex items-center gap-3">
                <ShoppingBag className="w-5 h-5 text-[#C9A45C]" aria-hidden="true" />
                <h2 className="font-display text-2xl font-semibold tracking-wide text-[#F4EFE6]">
                  {step === 'bag' && 'Your Order Bag'}
                  {step === 'checkout' && 'Checkout Details'}
                  {step === 'confirmed' && 'Demonstration Receipt'}
                </h2>
              </div>
              <button
                type="button"
                onClick={handleClose}
                aria-label="Close order drawer"
                className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg text-[#B8AFA3] hover:text-[#F4EFE6] hover:bg-white/5 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto px-6 py-6">
              {step === 'confirmed' ? (
                <div className="py-8 space-y-6">
                  <div className="w-14 h-14 rounded-full bg-[#C9A45C]/15 border border-[#C9A45C]/40 flex items-center justify-center text-[#C9A45C]">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <div className="space-y-2">
                    <p className="text-xs tracking-widest uppercase text-[#C9A45C]">
                      Demonstration Order Confirmed
                    </p>
                    <h3 className="font-display text-3xl font-semibold text-[#F4EFE6]">
                      Thank you, {customerName}
                    </h3>
                    <p className="text-sm text-[#B8AFA3] leading-relaxed">
                      Reference <span className="text-[#F4EFE6] font-medium tabular-nums">{orderRef}</span> has been recorded in this interactive preview.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-[#1C1917] border border-[#C9A45C]/25 space-y-2 text-sm">
                    <p className="font-medium text-[#C9A45C]">Interactive Demo Notice</p>
                    <p className="text-[#B8AFA3] leading-relaxed">
                      No payment processor or live kitchen dispatch is connected to this showcase. In a live Hark Empire deployment, this connects directly to Paystack, Flutterwave, and kitchen POS tickets.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleClose}
                    className="w-full py-3.5 px-6 rounded-lg bg-[#C9A45C] text-[#0C0B0A] font-semibold text-sm hover:bg-[#D8B774] transition-colors whitespace-nowrap"
                  >
                    Return to Restaurant
                  </button>
                </div>
              ) : items.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-12 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-[#1C1917] border border-white/10 flex items-center justify-center text-[#C9A45C]/70">
                    <ShoppingBag className="w-7 h-7" />
                  </div>
                  <div className="space-y-1.5 max-w-xs">
                    <h3 className="font-display text-2xl text-[#F4EFE6]">Your bag is empty</h3>
                    <p className="text-sm text-[#9E9589]">
                      Select dishes from our open-fire menu or special tasting packages to begin an order.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleClose}
                    className="px-6 py-3 rounded-lg border border-[#C9A45C]/50 text-[#C9A45C] text-sm font-medium hover:bg-[#C9A45C]/10 transition-colors"
                  >
                    Browse Our Menu
                  </button>
                </div>
              ) : step === 'bag' ? (
                <div className="space-y-5">
                  <div className="p-3.5 rounded-lg bg-[#1C1917] border border-white/10 text-xs text-[#B8AFA3] leading-relaxed">
                    Demonstration Online Ordering: Add, adjust, or remove dishes below. Checkout is simulated with no live charge.
                  </div>
                  <ul className="divide-y divide-white/10">
                    {items.map((item) => (
                      <li key={item.id} className="py-4 flex gap-4">
                        <div className="w-20 h-20 rounded-lg overflow-hidden shrink-0 bg-[#1C1917]">
                          <ResilientImage
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0 flex flex-col justify-between">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <p className="text-xs text-[#9E9589]">{item.categoryLabel}</p>
                              <h4 className="text-sm font-semibold text-[#F4EFE6] leading-snug">
                                {item.name}
                              </h4>
                            </div>
                            <button
                              type="button"
                              onClick={() => onRemoveItem(item.id)}
                              aria-label={`Remove ${item.name}`}
                              className="p-1.5 text-[#9E9589] hover:text-red-400 transition-colors shrink-0"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>

                          <div className="flex items-center justify-between mt-3">
                            <div className="inline-flex items-center border border-white/15 rounded-lg bg-[#1C1917]">
                              <button
                                type="button"
                                onClick={() => onUpdateQuantity(item.id, -1)}
                                aria-label={`Decrease quantity of ${item.name}`}
                                className="w-8 h-8 flex items-center justify-center text-[#B8AFA3] hover:text-[#F4EFE6] transition-colors"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="px-2.5 text-xs font-medium tabular-nums text-[#F4EFE6]">
                                {item.quantity}
                              </span>
                              <button
                                type="button"
                                onClick={() => onUpdateQuantity(item.id, 1)}
                                aria-label={`Increase quantity of ${item.name}`}
                                className="w-8 h-8 flex items-center justify-center text-[#B8AFA3] hover:text-[#F4EFE6] transition-colors"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <span className="text-sm font-semibold text-[#C9A45C] tabular-nums">
                              {formatNaira(item.priceNaira * item.quantity)}
                            </span>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : (
                <form id="demo-checkout-form" onSubmit={handleCheckoutSubmit} className="space-y-5">
                  <div className="p-3.5 rounded-lg bg-[#1C1917] border border-[#C9A45C]/30 text-xs text-[#E5DEC9] leading-relaxed">
                    Demonstration Checkout: No real payment is collected. Submit to preview the instant confirmation workflow.
                  </div>

                  <div>
                    <span className="block text-xs font-medium text-[#B8AFA3] mb-2">
                      Fulfillment Method
                    </span>
                    <div className="grid grid-cols-2 gap-2 p-1 rounded-lg bg-[#1C1917] border border-white/10">
                      <button
                        type="button"
                        onClick={() => setFulfillment('delivery')}
                        className={`py-2.5 px-3 rounded-md text-xs font-medium transition-colors ${
                          fulfillment === 'delivery'
                            ? 'bg-[#C9A45C] text-[#0C0B0A]'
                            : 'text-[#B8AFA3] hover:text-[#F4EFE6]'
                        }`}
                      >
                        Lagos Express Delivery
                      </button>
                      <button
                        type="button"
                        onClick={() => setFulfillment('pickup')}
                        className={`py-2.5 px-3 rounded-md text-xs font-medium transition-colors ${
                          fulfillment === 'pickup'
                            ? 'bg-[#C9A45C] text-[#0C0B0A]'
                            : 'text-[#B8AFA3] hover:text-[#F4EFE6]'
                        }`}
                      >
                        Victoria Island Pickup
                      </button>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="checkout-name" className="block text-xs font-medium text-[#B8AFA3] mb-1.5">
                      Full Name
                    </label>
                    <input
                      id="checkout-name"
                      type="text"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. Toluwani Adeyemi"
                      className="w-full px-3.5 py-2.5 rounded-lg bg-[#1C1917] border border-white/15 text-sm text-[#F4EFE6] placeholder:text-[#6E665C] focus:outline-none focus:border-[#C9A45C]"
                    />
                  </div>

                  <div>
                    <label htmlFor="checkout-phone" className="block text-xs font-medium text-[#B8AFA3] mb-1.5">
                      Phone Number (WhatsApp / Call)
                    </label>
                    <input
                      id="checkout-phone"
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+234 800 000 0000"
                      className="w-full px-3.5 py-2.5 rounded-lg bg-[#1C1917] border border-white/15 text-sm text-[#F4EFE6] placeholder:text-[#6E665C] focus:outline-none focus:border-[#C9A45C]"
                    />
                  </div>

                  {fulfillment === 'delivery' && (
                    <div>
                      <label htmlFor="checkout-address" className="block text-xs font-medium text-[#B8AFA3] mb-1.5">
                        Delivery Address
                      </label>
                      <input
                        id="checkout-address"
                        type="text"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="Street, Ikoyi / Victoria Island / Lekki"
                        className="w-full px-3.5 py-2.5 rounded-lg bg-[#1C1917] border border-white/15 text-sm text-[#F4EFE6] placeholder:text-[#6E665C] focus:outline-none focus:border-[#C9A45C]"
                      />
                    </div>
                  )}

                  <div>
                    <label htmlFor="checkout-notes" className="block text-xs font-medium text-[#B8AFA3] mb-1.5">
                      Spice Preference or Allergy Notes
                    </label>
                    <textarea
                      id="checkout-notes"
                      rows={2}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Optional kitchen instructions..."
                      className="w-full px-3.5 py-2.5 rounded-lg bg-[#1C1917] border border-white/15 text-sm text-[#F4EFE6] placeholder:text-[#6E665C] focus:outline-none focus:border-[#C9A45C]"
                    />
                  </div>

                  {formError && (
                    <p className="text-xs text-red-400" role="alert">
                      {formError}
                    </p>
                  )}
                </form>
              )}
            </div>

            {/* Footer totals & CTA */}
            {items.length > 0 && step !== 'confirmed' && (
              <div className="border-t border-white/10 px-6 py-5 bg-[#0F0E0C] space-y-4">
                <div className="space-y-1.5 text-sm">
                  <div className="flex justify-between text-[#B8AFA3]">
                    <span>Subtotal</span>
                    <span className="tabular-nums">{formatNaira(subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-[#B8AFA3]">
                    <span>VAT (7.5%)</span>
                    <span className="tabular-nums">{formatNaira(vat)}</span>
                  </div>
                  <div className="flex justify-between text-[#B8AFA3]">
                    <span>{fulfillment === 'delivery' ? 'Courier Dispatch' : 'Pickup'}</span>
                    <span className="tabular-nums">
                      {deliveryFee > 0 ? formatNaira(deliveryFee) : '₦0'}
                    </span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-white/10 text-base font-semibold text-[#F4EFE6]">
                    <span>Total</span>
                    <span className="text-[#C9A45C] tabular-nums">{formatNaira(total)}</span>
                  </div>
                </div>

                {step === 'bag' ? (
                  <button
                    type="button"
                    onClick={() => setStep('checkout')}
                    className="w-full py-3.5 px-6 rounded-lg bg-[#C9A45C] text-[#0C0B0A] font-semibold text-sm hover:bg-[#D8B774] transition-colors flex items-center justify-center gap-2 whitespace-nowrap"
                  >
                    <span>Proceed to Checkout</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                ) : (
                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => setStep('bag')}
                      className="px-4 py-3.5 rounded-lg border border-white/15 text-sm font-medium text-[#B8AFA3] hover:text-[#F4EFE6] hover:bg-white/5 transition-colors whitespace-nowrap"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      form="demo-checkout-form"
                      className="flex-1 py-3.5 px-6 rounded-lg bg-[#C9A45C] text-[#0C0B0A] font-semibold text-sm hover:bg-[#D8B774] transition-colors whitespace-nowrap"
                    >
                      Place Demo Order ({formatNaira(total)})
                    </button>
                  </div>
                )}
              </div>
            )}
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );
}
