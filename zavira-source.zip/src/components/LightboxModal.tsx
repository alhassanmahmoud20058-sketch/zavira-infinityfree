import { useEffect } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import type { GalleryPhoto } from '../data/restaurantData';
import { ResilientImage } from './ResilientImage';

interface LightboxModalProps {
  photos: GalleryPhoto[];
  activeIndex: number | null;
  onClose: () => void;
  onSelectIndex: (index: number) => void;
}

export function LightboxModal({
  photos,
  activeIndex,
  onClose,
  onSelectIndex,
}: LightboxModalProps) {
  useEffect(() => {
    if (activeIndex === null) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') {
        onSelectIndex((activeIndex + 1) % photos.length);
      }
      if (e.key === 'ArrowLeft') {
        onSelectIndex((activeIndex - 1 + photos.length) % photos.length);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeIndex, photos.length, onClose, onSelectIndex]);

  const photo = activeIndex !== null ? photos[activeIndex] : null;

  return (
    <AnimatePresence>
      {photo && activeIndex !== null && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 bg-black/92 backdrop-blur-md flex items-center justify-center p-4 sm:p-8"
          role="dialog"
          aria-modal="true"
          aria-label={photo.title}
        >
          <button
            type="button"
            onClick={onClose}
            aria-label="Close gallery lightbox"
            className="absolute top-4 right-4 sm:top-6 sm:right-6 min-w-[44px] min-h-[44px] rounded-full bg-white/10 hover:bg-white/20 text-[#F4EFE6] flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => onSelectIndex((activeIndex - 1 + photos.length) % photos.length)}
            aria-label="Previous photo"
            className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 min-w-[44px] min-h-[44px] rounded-full bg-black/60 border border-white/15 hover:border-[#C9A45C] text-[#F4EFE6] flex items-center justify-center transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => onSelectIndex((activeIndex + 1) % photos.length)}
            aria-label="Next photo"
            className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 min-w-[44px] min-h-[44px] rounded-full bg-black/60 border border-white/15 hover:border-[#C9A45C] text-[#F4EFE6] flex items-center justify-center transition-colors"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          <motion.div
            key={photo.id}
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.25 }}
            className="max-w-4xl w-full space-y-4"
          >
            <div className="rounded-2xl overflow-hidden bg-[#151311] border border-white/10 aspect-[4/3] max-h-[75vh] mx-auto">
              <ResilientImage
                src={photo.image}
                alt={photo.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-1">
              <div>
                <p className="text-xs text-[#C9A45C] tracking-wider uppercase">
                  {photo.category} · Frame {activeIndex + 1} of {photos.length}
                </p>
                <h3 className="font-display text-2xl text-[#F4EFE6]">{photo.title}</h3>
              </div>
              <p className="text-sm text-[#B8AFA3] max-w-md">{photo.caption}</p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
