import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useInView } from 'motion/react';
import {
  UtensilsCrossed,
  Flame,
  Award,
  Sparkles,
  Armchair,
  ShoppingBag,
  Star,
  Calendar,
  Clock,
  Users,
  Phone,
  Mail,
  MapPin,
  MessageCircle,
  Instagram,
  Facebook,
  Music2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Plus,
  Minus,
  CheckCircle2,
  Menu,
  X,
  ArrowUpRight,
  ChefHat,
  Leaf,
  HeartHandshake,
} from 'lucide-react';
import {
  MENU_CATEGORIES,
  MENU_ITEMS,
  SPECIAL_OFFERS,
  GALLERY_PHOTOS,
  TESTIMONIALS,
  IMAGES,
  formatNaira,
  type MenuCategory,
} from './data/restaurantData';
import { ResilientImage } from './components/ResilientImage';
import { CartDrawer, type CartItem } from './components/CartDrawer';
import { LightboxModal } from './components/LightboxModal';
import { LocationMapCard } from './components/LocationMapCard';

function AnimatedCounter({
  target,
  suffix = '',
  decimals = 0,
}: {
  target: number;
  suffix?: string;
  decimals?: number;
}) {
  const ref = useRef<HTMLSpanElement | null>(null);
  const isInView = useInView(ref, { once: true, margin: '-40px' });
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!isInView) return;
    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (prefersReduced) {
      setValue(target);
      return;
    }

    const duration = 1100;
    const start = performance.now();
    let frameId = 0;

    const tick = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(target * eased);
      if (progress < 1) {
        frameId = requestAnimationFrame(tick);
      } else {
        setValue(target);
      }
    };

    frameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frameId);
  }, [isInView, target]);

  return (
    <span ref={ref} className="tabular-nums">
      {decimals > 0 ? value.toFixed(decimals) : Math.round(value)}
      {suffix}
    </span>
  );
}

export default function App() {
  const [introLoaded, setIntroLoaded] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Menu & Cart state
  const [activeCategory, setActiveCategory] = useState<MenuCategory>('Starters');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);

  // Gallery Lightbox state
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  // Testimonials carousel state
  const [testimonialIdx, setTestimonialIdx] = useState(0);
  const [carouselPaused, setCarouselPaused] = useState(false);

  // Reservation form state
  const [resName, setResName] = useState('');
  const [resPhone, setResPhone] = useState('');
  const [resEmail, setResEmail] = useState('');
  const [resGuests, setResGuests] = useState('2 Guests');
  const [resDate, setResDate] = useState('2026-12-05');
  const [resTime, setResTime] = useState('19:30');
  const [resRequests, setResRequests] = useState('');
  const [resError, setResError] = useState('');
  const [resConfirmed, setResConfirmed] = useState(false);

  // Newsletter state
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterMessage, setNewsletterMessage] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => setIntroLoaded(true), 420);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const onScroll = () => {
      setIsScrolled(window.scrollY > 180);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (carouselPaused) return;
    const interval = setInterval(() => {
      setTestimonialIdx((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 5500);
    return () => clearInterval(interval);
  }, [carouselPaused]);

  const filteredMenu = MENU_ITEMS.filter((item) => item.category === activeCategory);

  const addToCart = (item: {
    id: string;
    name: string;
    priceNaira: number;
    image: string;
    categoryLabel: string;
  }) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.id === item.id);
      if (existing) {
        return prev.map((c) => (c.id === item.id ? { ...c, quantity: c.quantity + 1 } : c));
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const updateCartQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((c) => (c.id === id ? { ...c, quantity: c.quantity + delta } : c))
        .filter((c) => c.quantity > 0),
    );
  };

  const removeCartItem = (id: string) => {
    setCart((prev) => prev.filter((c) => c.id !== id));
  };

  const clearCart = () => setCart([]);

  const getItemQty = (id: string) => cart.find((c) => c.id === id)?.quantity ?? 0;

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce((sum, item) => sum + item.priceNaira * item.quantity, 0);

  const handleReservationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resName.trim() || !resPhone.trim() || !resEmail.trim() || !resDate) {
      setResError('Please complete your name, phone number, email address, and preferred date.');
      return;
    }
    if (!resEmail.includes('@')) {
      setResError('Please enter a valid email address.');
      return;
    }
    setResError('');
    setResConfirmed(true);
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim() || !newsletterEmail.includes('@')) {
      setNewsletterMessage('Please enter a valid email address.');
      return;
    }
    setNewsletterMessage(
      'Subscribed to the demonstration mailing list. No external emails will be sent.',
    );
    setNewsletterEmail('');
  };

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div id="top" className="min-h-screen bg-[#0C0B0A] text-[#F4EFE6] relative overflow-x-clip">
      {/* Subtle Loading Curtain (never blocks accessibility, clears smoothly) */}
      <AnimatePresence>
        {!introLoaded && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-0 z-[70] bg-[#0C0B0A] flex flex-col items-center justify-center pointer-events-none"
            aria-hidden="true"
          >
            <span className="font-display text-3xl sm:text-4xl tracking-[0.25em] text-[#C9A45C]">
              HARK EMPIRE
            </span>
            <span className="mt-2 text-xs tracking-[0.3em] uppercase text-[#9E9589]">
              Curating Experience
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* =====================================================================
          1. FIRST SCREEN / HARK EMPIRE PRESENTATION WELCOME SECTION
      ====================================================================== */}
      <section
        aria-label="Hark Empire Presentation Introduction"
        className="relative bg-[#090807] border-b border-[#C9A45C]/25 overflow-hidden"
      >
        <div
          className="absolute inset-0 pointer-events-none opacity-40"
          style={{
            background:
              'radial-gradient(ellipse 70% 60% at 50% 0%, rgba(201,164,92,0.18), transparent 70%)',
          }}
          aria-hidden="true"
        />

        <div className="relative max-w-6xl mx-auto px-5 sm:px-8 py-14 sm:py-20 text-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-6"
          >
            <div className="inline-flex items-center gap-3 text-xs tracking-[0.28em] uppercase text-[#C9A45C]">
              <span className="w-8 h-px bg-[#C9A45C]/60" aria-hidden="true" />
              <span>Hark Empire Hospitality Showcase</span>
              <span className="w-8 h-px bg-[#C9A45C]/60" aria-hidden="true" />
            </div>

            <h1 className="font-display font-bold text-2xl sm:text-4xl lg:text-[2.75rem] leading-[1.2] tracking-wide text-[#F4EFE6] max-w-5xl mx-auto text-balance">
              WELCOME TO THIS WEBSITE, WITNESS HOW BEAUTIFUL AND PROFESSIONAL YOUR WEBSITE COULD
              POSSIBLY BE. PRESENTED BY <span className="text-[#C9A45C]">HARK EMPIRE</span>
            </h1>

            <p className="text-sm sm:text-base text-[#B8AFA3] max-w-2xl mx-auto leading-relaxed">
              Below is a live, interactive fine-dining demonstration engineered to turn hungry
              visitors into booked tables and direct online orders.
            </p>

            <div className="pt-2 flex flex-wrap items-center justify-center gap-4">
              <button
                type="button"
                onClick={() => scrollToSection('restaurant-home')}
                className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-lg bg-[#C9A45C] text-[#0C0B0A] text-sm font-semibold hover:bg-[#D8B774] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Witness the Restaurant Experience</span>
                <ChevronDown className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('menu')}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg border border-[#C9A45C]/40 text-[#F4EFE6] text-sm font-medium hover:bg-[#C9A45C]/10 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Test Interactive Menu &amp; Cart</span>
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* =====================================================================
          2. STICKY NAVIGATION BAR (3-Zone Top Bar Contract)
      ====================================================================== */}
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#0C0B0A]/92 backdrop-blur-md border-b border-[#C9A45C]/20 shadow-lg'
            : 'bg-[#0C0B0A]/80 backdrop-blur-sm border-b border-white/10'
        }`}
      >
        <div className="max-w-7xl mx-auto px-5 sm:px-8 h-16 sm:h-18 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <a
            href="#restaurant-home"
            className="font-display text-2xl sm:text-[1.75rem] font-semibold tracking-[0.14em] text-[#F4EFE6] hover:text-[#C9A45C] transition-colors whitespace-nowrap shrink-0"
          >
            ZAVIRA
          </a>

          {/* Zone 2: Concise Single-Line Text Navigation Links */}
          <nav
            aria-label="Primary Navigation"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-[#D6CEC2]"
          >
            <a
              href="#about"
              className="hover:text-[#C9A45C] border-b border-transparent hover:border-[#C9A45C] py-1 transition-colors whitespace-nowrap shrink-0"
            >
              About Us
            </a>
            <a
              href="#menu"
              className="hover:text-[#C9A45C] border-b border-transparent hover:border-[#C9A45C] py-1 transition-colors whitespace-nowrap shrink-0"
            >
              Our Menu
            </a>
            <a
              href="#gallery"
              className="hover:text-[#C9A45C] border-b border-transparent hover:border-[#C9A45C] py-1 transition-colors whitespace-nowrap shrink-0"
            >
              Gallery
            </a>
            <a
              href="#reservations"
              className="hover:text-[#C9A45C] border-b border-transparent hover:border-[#C9A45C] py-1 transition-colors whitespace-nowrap shrink-0"
            >
              Reservations
            </a>
            <a
              href="#contact"
              className="hover:text-[#C9A45C] border-b border-transparent hover:border-[#C9A45C] py-1 transition-colors whitespace-nowrap shrink-0"
            >
              Contact
            </a>
          </nav>

          {/* Zone 3: Single Primary Action + Mobile Menu Trigger */}
          <div className="flex items-center gap-3 shrink-0">
            <a
              href="#reservations"
              className="hidden sm:inline-flex items-center justify-center px-5 py-2.5 rounded-lg bg-[#C9A45C] text-[#0C0B0A] text-xs font-semibold tracking-wide hover:bg-[#D8B774] transition-colors whitespace-nowrap shrink-0"
            >
              Book a Table
            </a>
            <button
              type="button"
              onClick={() => setMobileMenuOpen((v) => !v)}
              aria-label={mobileMenuOpen ? 'Close menu' : 'Open navigation menu'}
              aria-expanded={mobileMenuOpen}
              className="md:hidden min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg border border-white/15 text-[#F4EFE6] hover:border-[#C9A45C] transition-colors"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Drawer Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
              className="md:hidden bg-[#12100E] border-t border-white/10 px-6 py-5 space-y-3"
            >
              <div className="flex flex-col space-y-1 text-base font-medium text-[#E5DEC9]">
                <button
                  type="button"
                  onClick={() => scrollToSection('restaurant-home')}
                  className="text-left py-2.5 border-b border-white/5 hover:text-[#C9A45C]"
                >
                  Home
                </button>
                <button
                  type="button"
                  onClick={() => scrollToSection('about')}
                  className="text-left py-2.5 border-b border-white/5 hover:text-[#C9A45C]"
                >
                  About Us
                </button>
                <button
                  type="button"
                  onClick={() => scrollToSection('menu')}
                  className="text-left py-2.5 border-b border-white/5 hover:text-[#C9A45C]"
                >
                  Our Menu
                </button>
                <button
                  type="button"
                  onClick={() => scrollToSection('gallery')}
                  className="text-left py-2.5 border-b border-white/5 hover:text-[#C9A45C]"
                >
                  Gallery
                </button>
                <button
                  type="button"
                  onClick={() => scrollToSection('reservations')}
                  className="text-left py-2.5 border-b border-white/5 hover:text-[#C9A45C]"
                >
                  Reservations
                </button>
                <button
                  type="button"
                  onClick={() => scrollToSection('contact')}
                  className="text-left py-2.5 hover:text-[#C9A45C]"
                >
                  Contact
                </button>
              </div>
              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => scrollToSection('reservations')}
                  className="flex-1 py-3 rounded-lg bg-[#C9A45C] text-[#0C0B0A] text-sm font-semibold text-center"
                >
                  Book a Table
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setCartOpen(true);
                  }}
                  className="px-4 py-3 rounded-lg border border-[#C9A45C]/40 text-[#F4EFE6] text-sm font-medium flex items-center gap-2"
                >
                  <ShoppingBag className="w-4 h-4 text-[#C9A45C]" />
                  <span className="tabular-nums">{cartCount}</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* =====================================================================
          3. FULL-SCREEN HERO SECTION
      ====================================================================== */}
      <section
        id="restaurant-home"
        className="relative min-h-[88vh] flex items-center justify-center overflow-hidden bg-[#0C0B0A]"
      >
        <div className="absolute inset-0 overflow-hidden">
          <img
            src={IMAGES.hero}
            alt="ZAVIRA signature butter-poached lobster and suya-crusted lamb medallions"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover animate-slow-zoom"
          />
          <div
            className="absolute inset-0 bg-gradient-to-t from-[#0C0B0A] via-[#0C0B0A]/60 to-[#0C0B0A]/45"
            aria-hidden="true"
          />
        </div>

        {/* Subtle Floating Architectural Corner Ornament */}
        <div
          className="hidden lg:block absolute inset-10 border border-[#C9A45C]/20 pointer-events-none animate-float-gentle rounded-2xl"
          aria-hidden="true"
        />

        <div className="relative z-10 max-w-5xl mx-auto px-5 sm:px-8 py-24 text-center">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-6"
          >
            <p className="text-xs sm:text-sm tracking-[0.28em] uppercase text-[#C9A45C]">
              Victoria Island, Lagos · Open-Fire Fine Dining
            </p>

            <h2 className="font-display font-semibold text-6xl sm:text-7xl lg:text-[6.5rem] leading-[0.95] tracking-[0.08em] text-[#F4EFE6]">
              ZAVIRA
            </h2>

            <p className="font-display italic text-2xl sm:text-3xl lg:text-4xl text-[#E5DEC9] font-medium text-balance">
              Open Fire. West African Soul. Unforgettable Nights.
            </p>

            <p className="text-sm sm:text-base text-[#D6CEC2] max-w-xl mx-auto leading-relaxed">
              Where heirloom Nigerian ingredients meet wood-fired gastronomy, candlelit hospitality,
              and handcrafted botanical mixology in the heart of Lagos.
            </p>

            <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
              <a
                href="#menu"
                className="px-8 py-4 rounded-lg bg-[#C9A45C] text-[#0C0B0A] text-sm font-semibold tracking-wide hover:bg-[#D8B774] transition-colors whitespace-nowrap shrink-0"
              >
                Explore Our Menu
              </a>
              <a
                href="#reservations"
                className="px-8 py-4 rounded-lg bg-black/45 backdrop-blur-md border border-[#F4EFE6]/30 text-[#F4EFE6] text-sm font-semibold tracking-wide hover:border-[#C9A45C] hover:text-[#C9A45C] transition-colors whitespace-nowrap shrink-0"
              >
                Reserve a Table
              </a>
            </div>
          </motion.div>
        </div>

        {/* Smooth Scroll Cue */}
        <a
          href="#about"
          aria-label="Scroll to About Us"
          className="absolute bottom-7 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-1.5 text-xs tracking-[0.22em] uppercase text-[#C9A45C]/80 hover:text-[#C9A45C] transition-colors"
        >
          <span>Discover</span>
          <ChevronDown className="w-4 h-4 animate-bounce" />
        </a>
      </section>

      {/* =====================================================================
          4. ABOUT THE RESTAURANT + ANIMATED STATISTICS (Warm Ivory Section)
      ====================================================================== */}
      <section id="about" className="bg-[#F6F2EA] text-[#171411] py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 space-y-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-stretch">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
              className="lg:col-span-6 flex flex-col justify-between space-y-8"
            >
              <div className="space-y-5">
                <p className="text-xs tracking-[0.24em] uppercase text-[#6B1D26] font-semibold">
                  01. Culinary Heritage &amp; Philosophy
                </p>
                <h2 className="font-display text-4xl sm:text-5xl font-semibold leading-[1.1] text-[#171411] text-balance">
                  Crafted Over White Oak Embers, Rooted in Nigerian Terroir
                </h2>
                <p className="text-base text-[#4A433B] leading-[1.75]">
                  Founded in Victoria Island, ZAVIRA celebrates the bold warmth of West African
                  hospitality through contemporary open-fire technique. Every morning begins with
                  direct-farm harvests from Ogun State, wild-caught Atlantic seafood from Lagos
                  fishermen, and single-origin spices roasted fresh in our hearth kitchen.
                </p>
                <p className="text-base text-[#4A433B] leading-[1.75]">
                  From our signature cherrywood-smoked Jollof and dry-aged suya ribeye to attentive,
                  unhurried tableside service, every course is composed to make business dinners,
                  family feasts, and milestone evenings feel extraordinary.
                </p>
              </div>

              <div className="pt-6 border-t border-[#171411]/12 grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-display text-2xl font-semibold text-[#171411]">
                    Farm-to-Hearth Sourcing
                  </h3>
                  <p className="mt-1.5 text-sm text-[#574F46] leading-relaxed">
                    Daily deliveries of heirloom Ofada grains, Ondo cacao, and fresh lagoon catch.
                  </p>
                </div>
                <div>
                  <h3 className="font-display text-2xl font-semibold text-[#171411]">
                    Unhurried Hospitality
                  </h3>
                  <p className="mt-1.5 text-sm text-[#574F46] leading-relaxed">
                    Dedicated sommeliers, private dining suites, and bespoke tasting menus.
                  </p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="lg:col-span-6"
            >
              <div className="rounded-2xl overflow-hidden shadow-xl bg-[#1C1917] h-full min-h-[380px] lg:min-h-[520px]">
                <ResilientImage
                  src={IMAGES.interior}
                  alt="ZAVIRA candlelit dining room and open hearth kitchen"
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>
          </div>

          {/* Full-width 4-Column Animated Statistics Strip */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 pt-12 border-t border-[#171411]/15">
            <div className="space-y-1">
              <div className="font-display text-4xl sm:text-5xl font-semibold text-[#6B1D26]">
                <AnimatedCounter target={14} suffix="+" />
              </div>
              <p className="text-sm font-medium text-[#171411]">Years of Culinary Mastery</p>
              <p className="text-xs text-[#6B6258]">Open-fire &amp; fine dining pedigree</p>
            </div>
            <div className="space-y-1">
              <div className="font-display text-4xl sm:text-5xl font-semibold text-[#6B1D26]">
                <AnimatedCounter target={100} suffix="%" />
              </div>
              <p className="text-sm font-medium text-[#171411]">Fresh Regional Produce</p>
              <p className="text-xs text-[#6B6258]">Direct farm &amp; Atlantic catch daily</p>
            </div>
            <div className="space-y-1">
              <div className="font-display text-4xl sm:text-5xl font-semibold text-[#6B1D26]">
                <AnimatedCounter target={4.9} decimals={1} suffix="/5" />
              </div>
              <p className="text-sm font-medium text-[#171411]">Guest Satisfaction Rating</p>
              <p className="text-xs text-[#6B6258]">Demonstration dining benchmark</p>
            </div>
            <div className="space-y-1">
              <div className="font-display text-4xl sm:text-5xl font-semibold text-[#6B1D26]">
                <AnimatedCounter target={18} />
              </div>
              <p className="text-sm font-medium text-[#171411]">Signature Hearth Creations</p>
              <p className="text-xs text-[#6B6258]">Across six curated menu chapters</p>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================================
          5. OUR MENU & INTERACTIVE ONLINE ORDERING
      ====================================================================== */}
      <section id="menu" className="bg-[#0C0B0A] text-[#F4EFE6] py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 space-y-12">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <div className="space-y-3 max-w-2xl">
              <p className="text-xs tracking-[0.24em] uppercase text-[#C9A45C]">
                02. Interactive Menu &amp; Online Ordering
              </p>
              <h2 className="font-display text-4xl sm:text-5xl font-semibold text-[#F4EFE6] text-balance">
                A Curated Study in Smoke, Spice &amp; Coastal Freshness
              </h2>
              <p className="text-sm sm:text-base text-[#B8AFA3] leading-relaxed">
                Select a category below to explore dishes and add directly to your demonstration
                order bag in Nigerian Naira.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setCartOpen(true)}
              className="inline-flex items-center justify-center gap-3 px-5 py-3 rounded-lg bg-[#1C1917] border border-[#C9A45C]/40 hover:border-[#C9A45C] text-sm font-medium text-[#F4EFE6] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4 text-[#C9A45C]" />
              <span>Order Bag</span>
              <span className="text-[#C9A45C] font-semibold tabular-nums">
                ({cartCount} · {formatNaira(cartSubtotal)})
              </span>
            </button>
          </div>

          {/* Interactive Category Switcher */}
          <div
            role="tablist"
            aria-label="Menu categories"
            className="flex flex-wrap gap-2 p-1.5 rounded-xl bg-[#151311] border border-white/10"
          >
            {MENU_CATEGORIES.map((category) => {
              const isActive = activeCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setActiveCategory(category)}
                  className={`px-4 py-2.5 rounded-lg text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-[#C9A45C] text-[#0C0B0A] font-semibold'
                      : 'text-[#B8AFA3] hover:text-[#F4EFE6] hover:bg-white/5'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>

          {/* Menu Grid */}
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7"
            >
              {filteredMenu.map((item) => {
                const qty = getItemQty(item.id);
                return (
                  <article
                    key={item.id}
                    className="group rounded-2xl bg-[#151311] border border-white/10 hover:border-[#C9A45C]/40 overflow-hidden flex flex-col transition-all duration-200 hover:-translate-y-0.5"
                  >
                    <div className="aspect-[4/3] overflow-hidden bg-[#1C1917]">
                      <ResilientImage
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                    </div>

                    <div className="p-6 flex-1 flex flex-col justify-between gap-5">
                      <div className="space-y-2.5">
                        <div className="flex items-center gap-2 text-xs text-[#9E9589]">
                          <span>{item.originNote}</span>
                          <span aria-hidden="true">·</span>
                          <span className="tabular-nums">{item.prepTime}</span>
                        </div>
                        <h3 className="font-display text-2xl font-semibold text-[#F4EFE6] leading-snug">
                          {item.name}
                        </h3>
                        <p className="text-sm text-[#B8AFA3] leading-relaxed">{item.description}</p>
                      </div>

                      <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-4">
                        <span className="text-lg font-semibold text-[#C9A45C] tabular-nums">
                          {formatNaira(item.priceNaira)}
                        </span>

                        {qty > 0 ? (
                          <div className="inline-flex items-center rounded-lg bg-[#1C1917] border border-[#C9A45C]/50">
                            <button
                              type="button"
                              onClick={() => updateCartQuantity(item.id, -1)}
                              aria-label={`Remove one ${item.name}`}
                              className="w-10 h-10 flex items-center justify-center text-[#F4EFE6] hover:text-[#C9A45C] transition-colors cursor-pointer"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="px-2.5 text-sm font-semibold tabular-nums text-[#F4EFE6]">
                              {qty}
                            </span>
                            <button
                              type="button"
                              onClick={() => updateCartQuantity(item.id, 1)}
                              aria-label={`Add one more ${item.name}`}
                              className="w-10 h-10 flex items-center justify-center text-[#F4EFE6] hover:text-[#C9A45C] transition-colors cursor-pointer"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() =>
                              addToCart({
                                id: item.id,
                                name: item.name,
                                priceNaira: item.priceNaira,
                                image: item.image,
                                categoryLabel: item.category,
                              })
                            }
                            className="px-4 py-2.5 rounded-lg bg-[#C9A45C] text-[#0C0B0A] text-xs font-semibold hover:bg-[#D8B774] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                          >
                            Add to Order
                          </button>
                        )}
                      </div>
                    </div>
                  </article>
                );
              })}
            </motion.div>
          </AnimatePresence>
        </div>
      </section>

      {/* =====================================================================
          6. SPECIAL OFFERS (Chef's Special, Today's Special, Family Packages)
      ====================================================================== */}
      <section className="bg-[#141210] border-y border-white/10 py-20 sm:py-24">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 space-y-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-3 max-w-2xl">
              <p className="text-xs tracking-[0.24em] uppercase text-[#C9A45C]">
                03. Limited-Time Experiences &amp; Packages
              </p>
              <h2 className="font-display text-4xl sm:text-5xl font-semibold text-[#F4EFE6] text-balance">
                Chef&apos;s Specials &amp; Celebration Feasts
              </h2>
            </div>
            <p className="text-sm text-[#B8AFA3] max-w-md">
              Curated multi-course tastings and shareable family platters crafted for memorable
              evenings.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-7">
            {SPECIAL_OFFERS.map((offer) => (
              <div
                key={offer.id}
                className="rounded-2xl bg-[#1A1714] border border-[#C9A45C]/25 overflow-hidden flex flex-col justify-between"
              >
                <div>
                  <div className="aspect-[4/3] overflow-hidden bg-[#1C1917]">
                    <ResilientImage
                      src={offer.image}
                      alt={offer.title}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 space-y-3">
                    <p className="text-xs tracking-wider uppercase text-[#C9A45C] font-semibold">
                      {offer.label}
                    </p>
                    <h3 className="font-display text-2xl sm:text-3xl font-semibold text-[#F4EFE6] leading-tight">
                      {offer.title}
                    </h3>
                    <p className="text-xs text-[#9E9589]">{offer.subtitle}</p>
                    <p className="text-sm text-[#B8AFA3] leading-relaxed">{offer.description}</p>
                  </div>
                </div>

                <div className="px-6 pb-6 pt-4 border-t border-white/10 space-y-4">
                  <div className="flex items-baseline justify-between gap-3">
                    <div className="flex items-baseline gap-2.5">
                      <span className="text-xl font-semibold text-[#C9A45C] tabular-nums">
                        {formatNaira(offer.priceNaira)}
                      </span>
                      <span className="text-xs text-[#8C8378] line-through tabular-nums">
                        {formatNaira(offer.originalPriceNaira)}
                      </span>
                    </div>
                    <span className="text-xs text-[#B8AFA3]">{offer.serves}</span>
                  </div>

                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        addToCart({
                          id: offer.id,
                          name: offer.title,
                          priceNaira: offer.priceNaira,
                          image: offer.image,
                          categoryLabel: offer.label,
                        });
                        setCartOpen(true);
                      }}
                      className="flex-1 py-3 px-4 rounded-lg bg-[#C9A45C] text-[#0C0B0A] text-xs font-semibold hover:bg-[#D8B774] transition-colors whitespace-nowrap cursor-pointer"
                    >
                      Order Package
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setResRequests(`Interested in: ${offer.title}`);
                        scrollToSection('reservations');
                      }}
                      className="py-3 px-4 rounded-lg border border-white/20 text-[#F4EFE6] text-xs font-medium hover:border-[#C9A45C] hover:text-[#C9A45C] transition-colors whitespace-nowrap cursor-pointer"
                    >
                      Book Tasting
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* =====================================================================
          7. FOOD & ATMOSPHERE GALLERY (Asymmetrical Grid + Lightbox)
      ====================================================================== */}
      <section id="gallery" className="bg-[#0C0B0A] py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 space-y-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-3 max-w-2xl">
              <p className="text-xs tracking-[0.24em] uppercase text-[#C9A45C]">
                04. Visual Showcase
              </p>
              <h2 className="font-display text-4xl sm:text-5xl font-semibold text-[#F4EFE6] text-balance">
                Inside the Kitchen &amp; Candlelit Dining Room
              </h2>
            </div>
            <p className="text-sm text-[#B8AFA3]">
              Click any frame to open the full-resolution lightbox view.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 auto-rows-[230px] sm:auto-rows-[260px] gap-4">
            {GALLERY_PHOTOS.map((photo, index) => (
              <button
                key={photo.id}
                type="button"
                onClick={() => setLightboxIndex(index)}
                className={`group relative rounded-2xl overflow-hidden bg-[#151311] border border-white/10 text-left cursor-pointer ${photo.spanClass}`}
              >
                <ResilientImage
                  src={photo.image}
                  alt={photo.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div
                  className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent opacity-90 group-hover:opacity-100 transition-opacity"
                  aria-hidden="true"
                />
                <div className="absolute bottom-0 inset-x-0 p-5 flex items-end justify-between gap-4">
                  <div>
                    <p className="text-xs text-[#C9A45C]">{photo.category}</p>
                    <h3 className="font-display text-xl sm:text-2xl font-semibold text-[#F4EFE6]">
                      {photo.title}
                    </h3>
                  </div>
                  <span className="w-9 h-9 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-[#F4EFE6] group-hover:bg-[#C9A45C] group-hover:text-[#0C0B0A] transition-colors shrink-0">
                    <ArrowUpRight className="w-4 h-4" />
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* =====================================================================
          8. WHY CHOOSE US + CUSTOMER TESTIMONIALS (Warm Ivory Contrast Band)
      ====================================================================== */}
      <section id="testimonials" className="bg-[#F6F2EA] text-[#171411] py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 space-y-20">
          {/* Why Choose Us */}
          <div className="space-y-12">
            <div className="max-w-2xl space-y-3">
              <p className="text-xs tracking-[0.24em] uppercase text-[#6B1D26] font-semibold">
                05. The ZAVIRA Standard
              </p>
              <h2 className="font-display text-4xl sm:text-5xl font-semibold text-[#171411] text-balance">
                Why Discerning Guests Choose Our Table
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-10">
              {[
                {
                  icon: Leaf,
                  title: 'Fresh Daily Ingredients',
                  desc: 'Sourced directly from partner farms and morning coastal markets with zero frozen shortcuts.',
                },
                {
                  icon: ChefHat,
                  title: 'Experienced Culinary Team',
                  desc: 'Led by chefs trained across Lagos, London, and Cape Town in open-fire gastronomy.',
                },
                {
                  icon: HeartHandshake,
                  title: 'Exceptional Guest Service',
                  desc: 'Warm, intuitive hospitality from valet arrival through final digestif service.',
                },
                {
                  icon: Armchair,
                  title: 'Comfortable Dining Room',
                  desc: 'Acoustically balanced seating, natural stone, and warm architectural candlelight.',
                },
                {
                  icon: Flame,
                  title: 'Unforgettable Flavours',
                  desc: 'Balanced smoke, slow-simmered stocks, and freshly milled West African aromatics.',
                },
                {
                  icon: UtensilsCrossed,
                  title: 'Effortless Online Ordering',
                  desc: 'Instant table reservations and seamless ordering built for desktop and mobile.',
                },
              ].map((pillar) => {
                const Icon = pillar.icon;
                return (
                  <div
                    key={pillar.title}
                    className="pt-6 border-t border-[#171411]/15 space-y-3 group"
                  >
                    <div className="w-11 h-11 rounded-xl bg-[#171411] text-[#C9A45C] flex items-center justify-center group-hover:bg-[#6B1D26] transition-colors">
                      <Icon className="w-5 h-5" aria-hidden="true" />
                    </div>
                    <h3 className="font-display text-2xl font-semibold text-[#171411]">
                      {pillar.title}
                    </h3>
                    <p className="text-sm text-[#4A433B] leading-relaxed">{pillar.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Adjacent Social Proof: Customer Testimonials Carousel */}
          <div
            onMouseEnter={() => setCarouselPaused(true)}
            onMouseLeave={() => setCarouselPaused(false)}
            className="rounded-2xl bg-[#151311] text-[#F4EFE6] p-8 sm:p-12 border border-[#171411]/10"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-8 border-b border-white/10">
              <div>
                <p className="text-xs tracking-[0.22em] uppercase text-[#C9A45C]">
                  Guest Impressions · Demonstration Reviews
                </p>
                <h3 className="font-display text-3xl sm:text-4xl font-semibold mt-1">
                  Voices From Our Dining Room
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setTestimonialIdx(
                      (prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length,
                    )
                  }
                  aria-label="Previous testimonial"
                  className="w-11 h-11 rounded-lg border border-white/15 hover:border-[#C9A45C] flex items-center justify-center text-[#F4EFE6] transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setTestimonialIdx((prev) => (prev + 1) % TESTIMONIALS.length)}
                  aria-label="Next testimonial"
                  className="w-11 h-11 rounded-lg border border-white/15 hover:border-[#C9A45C] flex items-center justify-center text-[#F4EFE6] transition-colors cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="pt-8 min-h-[190px] flex flex-col justify-between">
              <AnimatePresence mode="wait">
                <motion.div
                  key={TESTIMONIALS[testimonialIdx].id}
                  initial={{ opacity: 0, x: 16 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -16 }}
                  transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                  className="space-y-6"
                >
                  <div className="flex items-center gap-1 text-[#C9A45C]" aria-label="5 out of 5 stars">
                    {Array.from({ length: TESTIMONIALS[testimonialIdx].rating }).map((_, idx) => (
                      <Star key={idx} className="w-4 h-4 fill-current" />
                    ))}
                  </div>

                  <blockquote className="font-display text-2xl sm:text-3xl leading-snug text-[#F4EFE6] max-w-4xl">
                    &ldquo;{TESTIMONIALS[testimonialIdx].quote}&rdquo;
                  </blockquote>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2">
                    <div>
                      <p className="text-sm font-semibold text-[#F4EFE6]">
                        {TESTIMONIALS[testimonialIdx].name}
                      </p>
                      <p className="text-xs text-[#9E9589]">
                        {TESTIMONIALS[testimonialIdx].role}
                      </p>
                    </div>
                    <p className="text-xs text-[#C9A45C]">
                      Ordered: {TESTIMONIALS[testimonialIdx].dishMentioned}
                    </p>
                  </div>
                </motion.div>
              </AnimatePresence>

              <div className="flex items-center gap-2 mt-8">
                {TESTIMONIALS.map((item, idx) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setTestimonialIdx(idx)}
                    aria-label={`View review by ${item.name}`}
                    className={`h-1.5 rounded-full transition-all cursor-pointer ${
                      idx === testimonialIdx ? 'w-8 bg-[#C9A45C]' : 'w-3 bg-white/20'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================================
          9. TABLE RESERVATIONS
      ====================================================================== */}
      <section id="reservations" className="bg-[#0C0B0A] text-[#F4EFE6] py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-5 space-y-6">
            <p className="text-xs tracking-[0.24em] uppercase text-[#C9A45C]">
              06. Table Reservations
            </p>
            <h2 className="font-display text-4xl sm:text-5xl font-semibold text-[#F4EFE6] text-balance">
              Reserve Your Evening at the Hearth
            </h2>
            <p className="text-sm sm:text-base text-[#B8AFA3] leading-relaxed">
              Book an intimate table for two, an executive dinner, or our private dining suite.
              Walk-ins are warmly welcomed at our Smoked Zobo Cocktail Bar.
            </p>

            <div className="pt-6 border-t border-white/10 space-y-4 text-sm">
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-[#C9A45C] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="font-medium text-[#F4EFE6]">Dining Hours (Demonstration)</p>
                  <p className="text-[#9E9589]">Tue – Thu: 12:00 PM – 11:00 PM</p>
                  <p className="text-[#9E9589]">Fri – Sun: 12:00 PM – 1:00 AM</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Award className="w-5 h-5 text-[#C9A45C] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="font-medium text-[#F4EFE6]">Private Chef&apos;s Table</p>
                  <p className="text-[#9E9589]">
                    Accommodates up to 16 guests with custom tasting menus and wine pairing.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className="rounded-2xl bg-[#151311] border border-[#C9A45C]/25 p-6 sm:p-10">
              {resConfirmed ? (
                <div className="py-8 space-y-5">
                  <div className="w-12 h-12 rounded-full bg-[#C9A45C]/15 border border-[#C9A45C]/40 flex items-center justify-center text-[#C9A45C]">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div className="space-y-2">
                    <p className="text-xs tracking-widest uppercase text-[#C9A45C]">
                      Demonstration Booking Recorded
                    </p>
                    <h3 className="font-display text-3xl font-semibold text-[#F4EFE6]">
                      We look forward to welcoming you, {resName}
                    </h3>
                    <p className="text-sm text-[#B8AFA3] leading-relaxed">
                      Table request for <strong className="text-[#F4EFE6]">{resGuests}</strong> on{' '}
                      <strong className="text-[#F4EFE6] tabular-nums">{resDate}</strong> at{' '}
                      <strong className="text-[#F4EFE6] tabular-nums">{resTime}</strong>.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-[#1C1917] border border-white/10 text-xs text-[#B8AFA3] leading-relaxed">
                    <strong className="text-[#C9A45C]">Demonstration Notice:</strong> This
                    reservation form is an interactive demonstration and has not transmitted a live
                    booking to a restaurant backend.
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setResConfirmed(false);
                      setResName('');
                      setResPhone('');
                      setResEmail('');
                      setResRequests('');
                    }}
                    className="px-6 py-3 rounded-lg border border-[#C9A45C]/40 text-sm font-medium text-[#C9A45C] hover:bg-[#C9A45C]/10 transition-colors cursor-pointer"
                  >
                    Make Another Demo Reservation
                  </button>
                </div>
              ) : (
                <form onSubmit={handleReservationSubmit} className="space-y-5">
                  <div className="flex items-center justify-between gap-2 pb-4 border-b border-white/10">
                    <h3 className="font-display text-2xl font-semibold text-[#F4EFE6]">
                      Table Request Form
                    </h3>
                    <span className="text-xs text-[#9E9589]">Interactive Demo</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label htmlFor="res-name" className="block text-xs font-medium text-[#B8AFA3] mb-1.5">
                        Full Name
                      </label>
                      <input
                        id="res-name"
                        type="text"
                        value={resName}
                        onChange={(e) => setResName(e.target.value)}
                        placeholder="Adaeze Eze"
                        className="w-full px-4 py-3 rounded-lg bg-[#1C1917] border border-white/15 text-sm text-[#F4EFE6] placeholder:text-[#6E665C] focus:outline-none focus:border-[#C9A45C]"
                      />
                    </div>
                    <div>
                      <label htmlFor="res-phone" className="block text-xs font-medium text-[#B8AFA3] mb-1.5">
                        Phone Number
                      </label>
                      <input
                        id="res-phone"
                        type="tel"
                        value={resPhone}
                        onChange={(e) => setResPhone(e.target.value)}
                        placeholder="+234 800 000 0000"
                        className="w-full px-4 py-3 rounded-lg bg-[#1C1917] border border-white/15 text-sm text-[#F4EFE6] placeholder:text-[#6E665C] focus:outline-none focus:border-[#C9A45C]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label htmlFor="res-email" className="block text-xs font-medium text-[#B8AFA3] mb-1.5">
                        Email Address
                      </label>
                      <input
                        id="res-email"
                        type="email"
                        value={resEmail}
                        onChange={(e) => setResEmail(e.target.value)}
                        placeholder="guest@example.com"
                        className="w-full px-4 py-3 rounded-lg bg-[#1C1917] border border-white/15 text-sm text-[#F4EFE6] placeholder:text-[#6E665C] focus:outline-none focus:border-[#C9A45C]"
                      />
                    </div>
                    <div>
                      <label htmlFor="res-guests" className="block text-xs font-medium text-[#B8AFA3] mb-1.5">
                        Number of Guests
                      </label>
                      <div className="relative">
                        <Users className="w-4 h-4 text-[#C9A45C] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <select
                          id="res-guests"
                          value={resGuests}
                          onChange={(e) => setResGuests(e.target.value)}
                          className="w-full pl-10 pr-4 py-3 rounded-lg bg-[#1C1917] border border-white/15 text-sm text-[#F4EFE6] focus:outline-none focus:border-[#C9A45C]"
                        >
                          <option>1 Guest</option>
                          <option>2 Guests</option>
                          <option>4 Guests</option>
                          <option>6 Guests</option>
                          <option>8+ Private Table</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label htmlFor="res-date" className="block text-xs font-medium text-[#B8AFA3] mb-1.5">
                        Preferred Date
                      </label>
                      <div className="relative">
                        <Calendar className="w-4 h-4 text-[#C9A45C] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          id="res-date"
                          type="date"
                          value={resDate}
                          onChange={(e) => setResDate(e.target.value)}
                          className="w-full pl-10 pr-4 py-3 rounded-lg bg-[#1C1917] border border-white/15 text-sm text-[#F4EFE6] focus:outline-none focus:border-[#C9A45C]"
                        />
                      </div>
                    </div>
                    <div>
                      <label htmlFor="res-time" className="block text-xs font-medium text-[#B8AFA3] mb-1.5">
                        Preferred Time
                      </label>
                      <div className="relative">
                        <Clock className="w-4 h-4 text-[#C9A45C] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <select
                          id="res-time"
                          value={resTime}
                          onChange={(e) => setResTime(e.target.value)}
                          className="w-full pl-10 pr-4 py-3 rounded-lg bg-[#1C1917] border border-white/15 text-sm text-[#F4EFE6] focus:outline-none focus:border-[#C9A45C]"
                        >
                          <option value="13:00">1:00 PM (Lunch)</option>
                          <option value="15:30">3:30 PM (Afternoon)</option>
                          <option value="18:30">6:30 PM (Early Dinner)</option>
                          <option value="19:30">7:30 PM (Prime Seating)</option>
                          <option value="21:00">9:00 PM (Late Seating)</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="res-requests" className="block text-xs font-medium text-[#B8AFA3] mb-1.5">
                      Special Requests (Anniversary, Dietary Needs, Seating)
                    </label>
                    <textarea
                      id="res-requests"
                      rows={3}
                      value={resRequests}
                      onChange={(e) => setResRequests(e.target.value)}
                      placeholder="Window table, birthday dessert candle, nut allergy..."
                      className="w-full px-4 py-3 rounded-lg bg-[#1C1917] border border-white/15 text-sm text-[#F4EFE6] placeholder:text-[#6E665C] focus:outline-none focus:border-[#C9A45C]"
                    />
                  </div>

                  {resError && (
                    <p className="text-xs text-red-400" role="alert">
                      {resError}
                    </p>
                  )}

                  <button
                    type="submit"
                    className="w-full py-4 px-6 rounded-lg bg-[#C9A45C] text-[#0C0B0A] text-sm font-semibold hover:bg-[#D8B774] transition-colors cursor-pointer"
                  >
                    Confirm Reservation
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================================
          10. CONTACT, LOCATION & INSTAGRAM STRIP
      ====================================================================== */}
      <section id="contact" className="bg-[#141210] border-t border-white/10 py-20 sm:py-24">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 space-y-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            <div className="lg:col-span-5 flex flex-col justify-between space-y-8">
              <div className="space-y-4">
                <p className="text-xs tracking-[0.24em] uppercase text-[#C9A45C]">
                  07. Visit &amp; Concierge (Demonstration Details)
                </p>
                <h2 className="font-display text-4xl sm:text-5xl font-semibold text-[#F4EFE6]">
                  Find Us in Victoria Island
                </h2>
                <p className="text-sm text-[#B8AFA3] leading-relaxed">
                  All address, phone, and concierge details shown below are sample demonstration
                  details created for this Hark Empire presentation.
                </p>
              </div>

              <div className="space-y-4 text-sm">
                <div className="flex items-start gap-3.5">
                  <MapPin className="w-5 h-5 text-[#C9A45C] shrink-0 mt-0.5" aria-hidden="true" />
                  <div>
                    <p className="font-medium text-[#F4EFE6]">Address (Demo)</p>
                    <p className="text-[#B8AFA3]">
                      14B Adeola Odeku Street, Victoria Island, Lagos, Nigeria
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3.5">
                  <Phone className="w-5 h-5 text-[#C9A45C] shrink-0 mt-0.5" aria-hidden="true" />
                  <div>
                    <p className="font-medium text-[#F4EFE6]">Reservations Desk (Demo)</p>
                    <p className="text-[#B8AFA3] tabular-nums">+234 (0) 800 555 0199</p>
                  </div>
                </div>
                <div className="flex items-start gap-3.5">
                  <Mail className="w-5 h-5 text-[#C9A45C] shrink-0 mt-0.5" aria-hidden="true" />
                  <div>
                    <p className="font-medium text-[#F4EFE6]">Email Concierge (Demo)</p>
                    <p className="text-[#B8AFA3]">concierge@zavira-demo.example</p>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <a
                  href="https://wa.me/2348005550199"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2.5 px-5 py-3 rounded-lg bg-[#C9A45C] text-[#0C0B0A] text-xs font-semibold hover:bg-[#D8B774] transition-colors whitespace-nowrap"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Chat on WhatsApp</span>
                </a>
                <div className="flex items-center gap-2">
                  <a
                    href="https://instagram.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Instagram"
                    className="w-11 h-11 rounded-lg border border-white/15 hover:border-[#C9A45C] flex items-center justify-center text-[#E5DEC9] hover:text-[#C9A45C] transition-colors"
                  >
                    <Instagram className="w-4 h-4" />
                  </a>
                  <a
                    href="https://facebook.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Facebook"
                    className="w-11 h-11 rounded-lg border border-white/15 hover:border-[#C9A45C] flex items-center justify-center text-[#E5DEC9] hover:text-[#C9A45C] transition-colors"
                  >
                    <Facebook className="w-4 h-4" />
                  </a>
                  <a
                    href="https://tiktok.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="TikTok"
                    className="w-11 h-11 rounded-lg border border-white/15 hover:border-[#C9A45C] flex items-center justify-center text-[#E5DEC9] hover:text-[#C9A45C] transition-colors"
                  >
                    <Music2 className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7">
              <LocationMapCard />
            </div>
          </div>

          {/* Instagram-Style Photo Strip */}
          <div className="space-y-4 pt-8 border-t border-white/10">
            <div className="flex items-center justify-between">
              <p className="text-xs tracking-[0.2em] uppercase text-[#C9A45C]">
                @zavira.lagos · Nightly Moments
              </p>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-[#B8AFA3] hover:text-[#C9A45C] transition-colors inline-flex items-center gap-1"
              >
                <span>Follow Gallery</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              {[
                { img: IMAGES.jollofDuck, title: 'Firewood Jollof & Duck' },
                { img: IMAGES.zoboCocktail, title: 'Smoked Zobo Old Fashioned' },
                { img: IMAGES.suyaRibeye, title: 'Yaji Tomahawk Ribeye' },
                { img: IMAGES.plantainTartare, title: 'Sea Bass Tartare' },
                { img: IMAGES.cacaoDessert, title: 'Ondo Cacao Lava Tart' },
              ].map((post, i) => (
                <button
                  key={post.title}
                  type="button"
                  onClick={() => setLightboxIndex(i % GALLERY_PHOTOS.length)}
                  className="group relative aspect-square rounded-xl overflow-hidden bg-[#1C1917] cursor-pointer"
                >
                  <ResilientImage
                    src={post.img}
                    alt={post.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/35 transition-colors flex items-center justify-center">
                    <Instagram className="w-5 h-5 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================================
          11. SOPHISTICATED FOOTER
      ====================================================================== */}
      <footer className="bg-[#080706] border-t border-white/10 text-[#B8AFA3]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4 space-y-4">
            <span className="font-display text-3xl font-semibold tracking-[0.14em] text-[#F4EFE6]">
              ZAVIRA
            </span>
            <p className="text-sm leading-relaxed max-w-sm">
              Contemporary West African open-fire dining in Victoria Island, Lagos. Designed and
              presented by Hark Empire as a bespoke hospitality web experience.
            </p>
            <div className="flex items-center gap-3 pt-1">
              <Sparkles className="w-4 h-4 text-[#C9A45C]" aria-hidden="true" />
              <span className="text-xs text-[#C9A45C]">Presented by Hark Empire</span>
            </div>
          </div>

          <div className="lg:col-span-2 space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-[#F4EFE6]">
              Explore
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#restaurant-home" className="hover:text-[#C9A45C] transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-[#C9A45C] transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#menu" className="hover:text-[#C9A45C] transition-colors">
                  Our Menu
                </a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-[#C9A45C] transition-colors">
                  Gallery
                </a>
              </li>
              <li>
                <a href="#reservations" className="hover:text-[#C9A45C] transition-colors">
                  Reservations
                </a>
              </li>
            </ul>
          </div>

          <div className="lg:col-span-3 space-y-3 text-sm">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-[#F4EFE6]">
              Hours &amp; Location
            </h3>
            <p>14B Adeola Odeku Street, Victoria Island, Lagos</p>
            <p className="tabular-nums">Tue – Thu: 12:00 PM – 11:00 PM</p>
            <p className="tabular-nums">Fri – Sun: 12:00 PM – 1:00 AM</p>
            <p className="tabular-nums">+234 (0) 800 555 0199</p>
          </div>

          <div className="lg:col-span-3 space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-[#F4EFE6]">
              Seasonal Tasting Notes
            </h3>
            <p className="text-xs leading-relaxed">
              Receive invitations to chef tasting nights and new seasonal menus.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="space-y-2">
              <div className="flex gap-2">
                <input
                  type="email"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="Your email address"
                  aria-label="Newsletter email address"
                  className="flex-1 min-w-0 px-3.5 py-2.5 rounded-lg bg-[#151311] border border-white/15 text-xs text-[#F4EFE6] placeholder:text-[#6E665C] focus:outline-none focus:border-[#C9A45C]"
                />
                <button
                  type="submit"
                  className="px-4 py-2.5 rounded-lg bg-[#C9A45C] text-[#0C0B0A] text-xs font-semibold hover:bg-[#D8B774] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Join
                </button>
              </div>
              {newsletterMessage && (
                <p className="text-xs text-[#C9A45C]">{newsletterMessage}</p>
              )}
            </form>
          </div>
        </div>

        <div className="border-t border-white/10 py-6 px-5 sm:px-8 max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#8C8378]">
          <p>&copy; 2026 ZAVIRA Restaurant. All rights reserved (Demonstration Showcase).</p>
          <p>Web Experience Designed &amp; Presented by Hark Empire</p>
        </div>
      </footer>

      {/* Floating Order Bag Button when items are in bag */}
      <AnimatePresence>
        {cartCount > 0 && !cartOpen && (
          <motion.button
            type="button"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 16 }}
            transition={{ duration: 0.2 }}
            onClick={() => setCartOpen(true)}
            className="fixed bottom-5 right-5 z-40 inline-flex items-center gap-3 px-5 py-3.5 rounded-full bg-[#C9A45C] text-[#0C0B0A] shadow-2xl font-semibold text-sm hover:bg-[#D8B774] transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>View Order</span>
            <span className="tabular-nums">
              ({cartCount}) · {formatNaira(cartSubtotal)}
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Sliding Shopping Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cart}
        onUpdateQuantity={updateCartQuantity}
        onRemoveItem={removeCartItem}
        onClearCart={clearCart}
      />

      {/* Gallery Lightbox Modal */}
      <LightboxModal
        photos={GALLERY_PHOTOS}
        activeIndex={lightboxIndex}
        onClose={() => setLightboxIndex(null)}
        onSelectIndex={setLightboxIndex}
      />
    </div>
  );
}
